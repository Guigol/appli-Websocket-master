package Back_WS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
